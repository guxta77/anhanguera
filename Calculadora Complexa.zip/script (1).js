let expressao = "";

function adicionarNumero(numero) {
    if (expressao === "0") {
        expressao = numero;
    } else {
        expressao += numero;
    }
    atualizarDisplay();
}

function adicionarOperacao(operador) {
    if (expressao !== "" && !isNaN(expressao.slice(-1))) {
        expressao += operador;
    }
    atualizarDisplay();
}

function adicionarPonto() {
    let partes = expressao.split(/[\+\-\*\/]/);
    let ultimaParte = partes[partes.length - 1];

    if (!ultimaParte.includes(".")) {
        expressao += ".";
    }
    atualizarDisplay();
}

function calcular() {
    try {
        expressao = eval(expressao).toString();
    } catch (e) {
        expressao = "Erro";
    }
    atualizarDisplay();
}

function limpar() {
    expressao = "";
    atualizarDisplay();
}

function atualizarDisplay() {
    document.getElementById("display").textContent = expressao || "0";
}


